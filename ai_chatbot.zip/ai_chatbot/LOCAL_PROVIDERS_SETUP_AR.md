# إعداد LM Studio و Ollama كمزودي ذكاء اصطناعي محليين

تم تعديل تطبيق ai_chatbot لدعم الاتصال المحلي بخادمي **LM Studio** و **Ollama** عبر واجهة API المتوافقة مع OpenAI، مع دعم كامل لـ API Tokens.

## التغييرات المنجزة

### 1. إضافة المزودين الجدد
- **LM Studio**: `http://localhost:1234/v1` (افتراضي)
- **Ollama**: `http://localhost:11434/v1` (افتراضي)

### 2. الملفات المعدلة
- `ai_chatbot/utils/ai_providers.py`:
  - إضافة فئة `LMStudioProvider`
  - إضافة فئة `OllamaProvider`
  - دعم `base_url` مخصص
  - API Key اختياري (يستخدم قيمة افتراضية إذا لم يُحدد)
  
- `ai_chatbot/chatbot/doctype/chatbot_settings/chatbot_settings.json`:
  - إضافة "LM Studio" و "Ollama" إلى قائمة المزودين
  - إضافة حقل `API Base URL` (يظهر فقط عند اختيار مزود محلي)
  - إضافة حقول Fallback للمزودين المحليين
  - جعل API Key اختياري

## طريقة الإعداد

### الخطوة 1: تثبيت التطبيق المعدل
```bash
bench get-app https://github.com/sanjay-kumar001/ai_chatbot
# أو إذا كان مثبتاً مسبقاً:
cd apps/ai_chatbot
git pull
bench --site your-site migrate
bench build --app ai_chatbot
bench restart
```

### الخطوة 2: إعداد LM Studio

1. حمّل وشغّل LM Studio: https://lmstudio.ai
2. حمّل نموذج (مثل llama-3.1-8b-instruct)
3. فعّل الخادم المحلي: `Local Server` → Start Server (المنفذ 1234)
4. في ERPNext: **Chatbot Settings**
   - AI Provider: **LM Studio**
   - API Base URL: `http://localhost:1234/v1`
   - API Key: اتركه فارغاً أو اكتب `lm-studio`
   - Model: اسم النموذج المحمل (مثل `llama-3.1-8b-instruct`)

### الخطوة 3: إعداد Ollama

1. ثبّت Ollama: https://ollama.ai
```bash
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3.1
ollama serve
```
2. في ERPNext: **Chatbot Settings**
   - AI Provider: **Ollama**
   - API Base URL: `http://localhost:11434/v1`
   - API Key: اتركه فارغاً أو `ollama`
   - Model: `llama3.1` أو `mistral` أو أي نموذج محمل

### دعم API Tokens

كلا المزودين يدعمان المصادقة عبر التوكن:

**LM Studio:**
- في LM Studio → Settings → Enable authentication
- ضع التوكن في حقل API Key في Chatbot Settings

**Ollama:**
- إذا فعّلت المصادقة في Ollama (عبر reverse proxy مثل nginx)
- ضع `Authorization: Bearer YOUR_TOKEN` في API Key

الكود يرسل:
```
Authorization: Bearer <api_key>
```

## الميزات المدعومة

✅ Streaming (token-by-token)
✅ Tool calling (استدعاء أدوات ERPNext الـ80)
✅ Vision (إذا كان النموذج يدعم)
✅ Multi-turn conversations
✅ Fallback provider (يمكن جعل Ollama fallback لـ LM Studio)
✅ Temperature و Max Tokens

## أمثلة الاستخدام

### استخدام LM Studio مع نموذج محلي
```
AI Provider: LM Studio
API Base URL: http://192.168.1.100:1234/v1  (خادم في الشبكة)
Model: qwen2.5-14b-instruct
Temperature: 0.3
```

### استخدام Ollama مع API Token
```
AI Provider: Ollama
API Base URL: https://ollama.company.com/v1
API Key: sk-ollama-xxxxxx (مخزن مشفر)
Model: llama3.1:70b
```

## استكشاف الأخطاء

**خطأ Connection refused:**
- تأكد أن LM Studio/Ollama يعمل
- تحقق من المنفذ: `curl http://localhost:1234/v1/models`

**خطأ Model not found:**
- في LM Studio: تأكد النموذج محمل في Local Server
- في Ollama: `ollama list` ثم استخدم الاسم الدقيق

**الأداء بطيء:**
- استخدم نماذج أصغر (7B بدل 70B)
- فعّل GPU acceleration في LM Studio/Ollama
- قلل `max_tokens` إلى 2000

## الفروقات عن المزودين السحابيين

| الميزة | OpenAI/Claude | LM Studio/Ollama |
|--------|---------------|------------------|
| API Key | مطلوب | اختياري |
| الإنترنت | مطلوب | لا |
| التكلفة | بالاستخدام | مجاني محلياً |
| السرعة | عالية | تعتمد على الجهاز |
| الخصوصية | بيانات ترسل للسحابة | تبقى محلياً 100% |

## التحديث المستقبلي

للتحديث:
```bash
cd apps/ai_chatbot
git stash
git pull origin main
git stash pop  # إذا كان لديك تعديلات محلية
bench migrate
bench restart
```
